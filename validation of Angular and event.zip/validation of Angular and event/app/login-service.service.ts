import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import {CaptchaDto} from './capchaImageDto';
import { Observable, throwError } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class LoginServiceService {
  isImageLoading:boolean;
  url:string;
  constructor(private nativeHttp: HttpClient) { }


  getCaptcha():Observable<CaptchaDto>
     {
        this.url="https://api.yavun.com/api/user/register/captchaId";
         return this.nativeHttp.get<CaptchaDto>(this.url);
         
    }

    getImage(captchaDto:CaptchaDto): Observable<Blob> {
      alert("hit");
      const httpOptions = {
        headers: new HttpHeaders({ 
          'Access-Control-Allow-Origin':'*',
          responseType: 'blob'
        })
      };
      return this.nativeHttp.get(captchaDto.imagePath,{httpOptions});
    }
    
   
}
   



