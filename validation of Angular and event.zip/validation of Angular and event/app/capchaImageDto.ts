export class CaptchaDto{
    captchaId:number;
    imagePath:string;
}