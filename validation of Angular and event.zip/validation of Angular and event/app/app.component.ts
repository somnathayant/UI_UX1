import { CaptchaDto } from './capchaImageDto';
import { Component,OnInit} from '@angular/core';
import {LoginServiceService} from './login-service.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'surajproject';
  cpDto:CaptchaDto;
  imageToShow: any;
  isImageLoading:boolean;
  constructor(private ls:LoginServiceService ) { }


  ngOnInit() {
    
    
      this.ls.getCaptcha().subscribe((data)=>{
        this.cpDto=data;
       this.ls.getImage(this.cpDto).subscribe((data)=>{
        this.isImageLoading = true;
        this.createImageFromBlob(data);
        this.isImageLoading = false;

       },err=>{
        this.isImageLoading = false;
        console.log(err);
       }
       );
      },
      err=>{
   },
      );
  }

  createImageFromBlob(image: Blob) {
    alert("image hit");
    let reader = new FileReader();
    reader.addEventListener("load", () => {
       this.imageToShow = reader.result;
    }, false);
 
    if (image) {
       reader.readAsDataURL(image);
    }
 }

 
/* DataSubmit(){

    
    this.empService.saveEmp(emp).subscribe((data) => {
       

    },
      err => {
        alert("Employee not saved !");
      },
      () => { console.log('Method Executed') }
    );
          
        } */


}





