import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {LoginComponent} from './login/login.component';
import {DashboardComponent} from './dashboard/dashboard.component';
import {PageNotFoundComponent} from './page-not-found/page-not-found.component';
import { InventoryComponent } from './inventory/inventory.component';
import { PricingComponent } from './pricing/pricing.component';

const routes: Routes = [
  { path: 'login', component:LoginComponent},
  { path: '',   redirectTo: '/login', pathMatch:'full'},
  { path: 'inventory', component:DashboardComponent},
  { path: 'pricing', component:DashboardComponent},
  { path: 'home', component:DashboardComponent},
  {path: 'employee', loadChildren: () => import(`./Emp/emp.module`).then(emp => emp.EmpModule) },
  { path: '**', component: PageNotFoundComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
