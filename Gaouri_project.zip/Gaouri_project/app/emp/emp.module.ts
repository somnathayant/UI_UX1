import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { EmpRoutingModule } from './emp-routing.module';
import{DisplayComponent} from './display/display.component';
import{UpdateComponent} from './update/update.component';
import {EmpComponent} from './emp.component';

@NgModule({
  declarations: [
    DisplayComponent,
    UpdateComponent,
    EmpComponent
  ],
  imports: [
    CommonModule,
    EmpRoutingModule
  ]
})
export class EmpModule { }
