import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {LoginComponent} from './login/login.component';
import {DashboardComponent} from './dashboard/dashboard.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { EmpComponent } from './emp/emp.component';
import { DisplayComponent } from './Emp/display/display.component';
import { UpdateComponent } from './Emp/update/update.component';
import { InventoryComponent } from './inventory/inventory.component';
import { PricingComponent } from './pricing/pricing.component';
@NgModule({
  declarations: [
    AppComponent,LoginComponent,DashboardComponent, PageNotFoundComponent, InventoryComponent, PricingComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
