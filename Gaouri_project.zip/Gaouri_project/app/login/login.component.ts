import { Component, OnInit } from '@angular/core';
import { Validators, FormControl, FormGroup, FormBuilder } from '@angular/forms';
import {Router} from "@angular/router";
import { loginDto } from './loginDto.model';
import { authDto } from './auth.model';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  
  empLoginForm: FormGroup;
  loginDtoObj: loginDto;
  userCheck: Array<string>;
  status: boolean = false;

  auth: authDto;
  

  constructor(private fb: FormBuilder,  private route:Router) { }

  ngOnInit() {

    this.empLoginForm = this.fb.group({      // initializes all formcontrolnames and give the control to empForm hence it carries all values as a single object.
      'username': new FormControl(''),
      'password': new FormControl('')
  })

}

    loginEmp(emp:loginDto) {//same identical property for the formcontrolname
      sessionStorage.setItem("userName",emp.username);
      
      this.route.navigate(['/home']);
      
    }

  
    }


