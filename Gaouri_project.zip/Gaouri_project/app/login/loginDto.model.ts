export class loginDto{

    username:string;
    password:string;

}