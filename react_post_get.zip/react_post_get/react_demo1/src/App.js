import React from 'react';
import './App.css';
import { Route, BrowserRouter as Router, Switch, Link } from 'react-router-dom';
import CreateEmployee from './CreateEmployee';
function App() {
  return (
    <Router>
        <div className="container-fluid">

          <nav className="navbar navbar-expand-sm bg-dark navbar-dark">
            <ul className="navbar-nav">
              <li className="nav-item">
                <Link to={'/create'} className="nav-link">Create</Link>
              </li>
              
            </ul>
          </nav>

          <div className="App">
            <Switch>
              <div className="content">
                <Route exact path="/create" component={CreateEmployee} />
             </div>
            </Switch>
          </div>
        </div>
      </Router>
  );
}

export default App;
