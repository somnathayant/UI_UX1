import React from 'react';
import axios from 'axios';
export default class CreateEmployee extends React.Component {

    constructor(props) {
        super(props);
        this.onChangeEmployeeName = this.onChangeEmployeeName.bind(this);
        this.onChangeEmployeeDesiganation = this.onChangeEmployeeDesiganation.bind(this);
        this.onChangeEmployeeSalary = this.onChangeEmployeeSalary.bind(this);
        this.onSubmit = this.onSubmit.bind(this);
        /* axios.get("the url").then(res=>
            {
                obj1=res.data;
                this.state = {
                    employee_name:obj1.employee_name,
                    employee_desiganation:obj1.employee_desiganation,
                    employee_salary:obj1.employee_salary
                }
            }
            ).catch(function(error)
            {
                console.log(error);
            }
            );
 */
        this.state = {
            employee_name: '',
            employee_desiganation: '',
            employee_salary: '',
            employees:[]        }
    }
    onChangeEmployeeName(e) {
        this.setState({
            employee_name: e.target.value
        });
    }
    onChangeEmployeeDesiganation(e) {
        this.setState({
            employee_desiganation: e.target.value
        })
    }
    onChangeEmployeeSalary(e) {
        this.setState({
            employee_salary: e.target.value
        })
    }

    onSubmit(e) {
        var emp1 = {
            "id": 7,
            "employee_name": this.state.employee_name,
            "employee_desiganation": this.state.employee_desiganation,
            "employee_salary": this.state.employee_salary

        }

        //axios.post("http://localhost:3005/emps",emp1).then(res=>res.data);//for json server
      
         axios.get("http://localhost:3005/emps")
        .then(function (response) {
                alert("ok");
                for(var i=0;i<=response.data.length;i++){
                alert(response.data[i].employee_desiganation);
                }
                })               
                .catch(function (error) {
                
            }); 

            





        this.setState({
            employee_name: '',
            employee_desiganation: '',
            employee_salary: ''
        });
        e.preventDefault();
    }
    render() {
        return (
            <div style={{ marginTop: 10 }}>
                <h3>Create Employee</h3>
                
                
                <form onSubmit={this.onSubmit}>
                    
                    
                    <div className="form-group">
                        <label>Employee Name:  </label>
                        <input
                            type="text"
                            className="form-control"
                            value={this.state.employee_name}
                            onChange={this.onChangeEmployeeName}
                        />
                        <div id="error_name"></div>
                    </div>
                   
                    <div className="form-group">
                        <label>Desiganation: </label>
                        <input type="text"
                            className="form-control"
                            value={this.state.employee_desiganation}
                            onChange={this.onChangeEmployeeDesiganation}
                        />
                    </div>
                    <div className="form-group">
                        <label>Salary: </label>
                        <input type="text"
                            className="form-control"
                            
                            value={this.state.employee_salary}
                            onChange={this.onChangeEmployeeSalary}
                        />
                    </div>
                    <div id="error_salary"></div>
                    <div className="form-group">
                        <input type="submit" value="Save" className="btn btn-primary" />
                    </div>
                </form>
            </div>
        )
    }
}