
import { Injectable } from '@angular/core';
import { CanActivate,Router} from '@angular/router';




@Injectable({
  providedIn: 'root'
})

export class AuthDashService implements CanActivate {

  constructor() { }

  canActivate():boolean{

    alert("you are not allowed to use this function")
         return true;
    
   }


}


