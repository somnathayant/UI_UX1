
import { Injectable, OnInit } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
//import 'rxjs/Rx';
import{StudentDto} from './StudentDto';
import {EmpDto} from './empDto';
@Injectable({
  providedIn: 'root'
})
export class StudentService {

  awsUrl:string;
  url:string;
  constructor(private nativeHttp: HttpClient) { 

  }

//after calling the server side, the response is taken in observable and sent over as a response
saveStudent(studentDto:StudentDto): Observable<StudentDto> {
 
  //this.awsUrl="http://ec2-3-82-199-8.compute-1.amazonaws.com:8080/springbootdeploy/students/saveStudent"
  this.awsUrl="http://localhost:3000/emp";
   
   return this.nativeHttp.post<StudentDto>(this.awsUrl,studentDto);
}

  //listing all available employees
students():Observable<StudentDto[]> {
  this.awsUrl="http://ec2-3-82-199-8.compute-1.amazonaws.com:8080/springbootdeploy/students/students"
  
  //this.awsUrl="http://localhost:8080/students/students";
 
   //return this.nativeHttp.get(this.url).map(res => res.json());
   return this.nativeHttp.get<StudentDto[]>(this.awsUrl);
}

getEmpById(empId:string):Observable<EmpDto> {
  this.url="http://localhost:3000/emp/"+parseInt(empId);
   //return this.nativeHttp.get(this.url).map(res => res.json());
   return this.nativeHttp.get<EmpDto>(this.url);
}


}
