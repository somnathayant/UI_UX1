import { StudentDto } from './../StudentDto';
import { Component, OnInit } from '@angular/core';
import{StudentService} from '../studentService';

  
@Component({
  selector: 'app-display',
  templateUrl: './display.component.html',
  styleUrls: ['./display.component.css']
})
export class DisplayComponent implements OnInit {

  studentDtoList:StudentDto[];
  //studentService:StudentService;
  constructor(private studentService : StudentService) {
    
   }

  ngOnInit() {
    
    this.studentService.students().subscribe((data) => {
      this.studentDtoList=data;
   },
      err => {
        alert("Students not found !");
      },
      () => { console.log('Method Executed') }
    );

    
  }

}
