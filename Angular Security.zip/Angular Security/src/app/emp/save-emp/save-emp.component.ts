import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-save-emp',
  templateUrl: './save-emp.component.html',
  styleUrls: ['./save-emp.component.css']
})
export class SaveEmpComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
