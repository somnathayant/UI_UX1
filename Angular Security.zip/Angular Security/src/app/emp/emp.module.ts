import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { EmpRoutingModule } from './emp-routing.module';
import { SaveEmpComponent } from './save-emp/save-emp.component';
import { DisplayEmployeeComponent } from './display-employee/display-employee.component';
import { InserEmployeeComponent } from './inser-employee/inser-employee.component';


@NgModule({
  declarations: [SaveEmpComponent, DisplayEmployeeComponent, InserEmployeeComponent],
  imports: [
    CommonModule,
    EmpRoutingModule
  ]
})
export class EmpModule { }
