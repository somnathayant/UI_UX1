import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InserEmployeeComponent } from './inser-employee.component';

describe('InserEmployeeComponent', () => {
  let component: InserEmployeeComponent;
  let fixture: ComponentFixture<InserEmployeeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InserEmployeeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InserEmployeeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
