import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {SaveEmpComponent} from './save-emp/save-emp.component';
import { DisplayEmployeeComponent } from './display-employee/display-employee.component';
import { InserEmployeeComponent } from './inser-employee/inser-employee.component';

const routes: Routes = [
  { path: '', component:SaveEmpComponent},
  { path: 'displayEmployee', component:DisplayEmployeeComponent},
  { path: 'insertEmployee', component:InserEmployeeComponent},

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class EmpRoutingModule { }
