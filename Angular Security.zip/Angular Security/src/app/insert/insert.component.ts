import { Component, OnInit } from '@angular/core';
import { FormControl, Validators, FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import{StudentService} from '../studentService';
import { StudentDto } from './../StudentDto';

@Component({
  selector: 'app-insert',
  templateUrl: './insert.component.html',
  styleUrls: ['./insert.component.css']
})
export class InsertComponent implements OnInit {

  studentForm: FormGroup;
  constructor(private fb: FormBuilder, private studentService : StudentService, private route : Router) { }

  ngOnInit() {
    this.studentForm = this.fb.group({      // initializes all formcontrolnames and give the control to empForm hence it carries all values as a single object.
      'firstName' : new FormControl(''),
      'lastName' : new FormControl(''),
      'year' : new FormControl(''),
      'city' : new FormControl(''),
    });
  }

  registerStudent(studentDto:StudentDto){   //emp is the model class object
    
    this.studentService.saveStudent(studentDto).subscribe((data) => {
      
        alert("Student saved !");
        this.route.navigate(['/display']) ;
    },
      err => {
        alert("Student not saved !");
      },
      () => { console.log('Method Executed') }
    );
          
        }



}
