export class FileDto{
    fileName:string;
}