import { Injectable, OnInit } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import 'rxjs/Rx';
import {EmployeeDto} from './EmployeeDto.model';
import {ServerResponse} from '../serverResponse/serverResponse';

@Injectable()
export class EmpService {
  url: string;
  emp:EmployeeDto;
  empArray:EmployeeDto[];
  constructor(private nativeHttp: HttpClient) {

  }
  saveEmp(emp: EmployeeDto): Observable<ServerResponse> {
  
    this.url="http://localhost:8081/corsRestForAng4/saveEmpData";
     //return this.nativeHttp.post(this.url,emp).map(res => res.json());
     return this.nativeHttp.post<ServerResponse>(this.url,emp);
  }

  getEmpForUpdate(employeeId:number):Observable<EmployeeDto> {
    this.emp=new EmployeeDto();
   this.emp.empId=employeeId;
   this.url="http://localhost:8081/corsRestForAng4/findEmpById";
     //return this.nativeHttp.put(this.url,this.emp).map(res => res.json());
     return this.nativeHttp.put<EmployeeDto>(this.url,this.emp);
  }
  uploadFile(file: FormData): Observable<ServerResponse> {
    this.url="http://localhost:8081/corsRestForAng4/saveFile";
     //return this.nativeHttp.post(this.url,file).map(res => res.json());
     return this.nativeHttp.post<ServerResponse>(this.url,file);
  }

  emps():Observable<EmployeeDto[]> {
    this.url="http://localhost:8081/corsRestForAng4/emps";
     //return this.nativeHttp.get(this.url).map(res => res.json());
     return this.nativeHttp.get<EmployeeDto[]>(this.url);
  }

  viewResume(e:EmployeeDto):Observable<Blob> {
     this.url="http://localhost:8081/corsRestForAng4/downloadFile";
      //return this.nativeHttp.post(this.url,e).map(res => res.json());
      return this.nativeHttp.post<Blob>(this.url,e);
    }
    
}