
import { EmpService } from './employeeService.component'
import { Component, OnInit } from '@angular/core';
import { Validators, FormControl, FormGroup, FormBuilder } from '@angular/forms';
import { Router, NavigationExtras, ActivatedRoute } from "@angular/router";
import { EmployeeDto } from './EmployeeDto.model'

@Component({
  selector: 'parent',
  templateUrl: './viewEmployee.component.html',
})
export class ViewEmployeeComponent implements OnInit {

  emps: EmployeeDto[] = [];

  constructor(private empService: EmpService) {

  }
  ngOnInit() {
    this.empService.emps().subscribe((data) => {
      this.emps = data;
    },
      err => {
        alert("Employee not found !");
      },
      () => { console.log('Method Executed') }
    );
  }

  viewResume(e: EmployeeDto) {
    this.empService.viewResume(e).subscribe((data) => {
      const blob = new Blob([data]);
      alert(blob.size);
      const url = window.URL.createObjectURL(blob);
      window.open(url);
    },
      err => {
        alert("No Resume !");
      },
      () => { console.log('Method Executed') }
    );
    }
}



