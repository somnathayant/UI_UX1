import { Component } from '@angular/core';
@Component({
  selector: 'menubar',
  templateUrl: './menubar.component.html'
})
export class MenubarComponent { 

}