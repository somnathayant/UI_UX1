import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {SaveEmpComponent} from './Employee/saveEmployee.component';
import{UpdateEmpComponent} from './Employee/updateEmployee/updateEmployee.component';
import {EmployeeIdEntryComponent} from './Employee/updateEmployee/employeeIdEntry.component';
import {ViewEmployeeComponent} from './Employee/viewEmployee.component';
const routes: Routes = [

 {path:'',component:SaveEmpComponent},
                  {path:'home',component:SaveEmpComponent},
                  {path:'showUpdateComponent/:empId',component:UpdateEmpComponent},

                  {path:'updateEmployee',component:EmployeeIdEntryComponent},
                  
                  {path:'viewEmployee',component:ViewEmployeeComponent},
              
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
