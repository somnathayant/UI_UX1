import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {SaveEmpComponent} from './Employee/saveEmployee.component';
import{UpdateEmpComponent} from './Employee/updateEmployee/updateEmployee.component';
import {EmployeeIdEntryComponent} from './Employee/updateEmployee/employeeIdEntry.component';
import {ViewEmployeeComponent} from './Employee/viewEmployee.component';
import {HttpClientModule} from '@angular/common/http';
import {MenubarComponent} from './menubar.component';
import { ReactiveFormsModule }      from '@angular/forms';
import {EmpService} from './Employee/employeeService.component';
@NgModule({
  declarations: [
    AppComponent,SaveEmpComponent,UpdateEmpComponent,EmployeeIdEntryComponent,ViewEmployeeComponent,MenubarComponent,
    
  
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,AppRoutingModule,HttpClientModule,ReactiveFormsModule
  ],
  providers: [EmpService],
  bootstrap: [AppComponent]
})
export class AppModule { }
