import axios from 'axios';
import EmpDto from './EmpDto'
export class EmpService{


 saveEmp(){
     axios.post("http://localhost:3005/emps",obj).then(res=>res.data);//for json server
}


}