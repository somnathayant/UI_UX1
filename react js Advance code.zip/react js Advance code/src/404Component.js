import React from 'react';
import axios from 'axios';
export default class NotFoundComponent extends React.Component {

    constructor(props) {
        super(props);

    }

    render() {
        return (
            <h1>NOt Found</h1>
        )}
}