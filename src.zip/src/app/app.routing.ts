import {UpdateEmpComponent} from './Employee/updateEmployee/updateEmployee.component';
import {SaveEmpComponent} from './Employee/saveEmployee.component';
import { ModuleWithProviders } from '@angular/core';
import { RouterModule } from '@angular/router';

export const router:ModuleWithProviders=RouterModule.forRoot([
                 {path:'',component:SaveEmpComponent},

                 // {path:'mngComponent/:empName',component:ManagerComponent1},

                  {path:'updateEmployee',component:UpdateEmpComponent},
               
                
                      ])