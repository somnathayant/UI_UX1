import { Component, OnInit } from '@angular/core';
import { Validators, FormControl, FormGroup, FormBuilder } from '@angular/forms';
import { EmployeeDto } from './EmployeeDto.model';
import { EmpService } from './employeeService.component';
import {Router, NavigationExtras,ActivatedRoute} from "@angular/router";
import{ServerResponse} from '../serverResponse/serverResponse';
@Component({
  selector: 'parent',
  templateUrl: './saveEmployee.component.html',
})
export class SaveEmpComponent implements OnInit {
  empForm: FormGroup;
  empDtoObj: EmployeeDto;
  response:ServerResponse;
  constructor(private fb: FormBuilder,private empService:EmpService) {

  }
  ngOnInit() {
    this.empForm = this.fb.group({
      'name': new FormControl(''),
      'salary': new FormControl(''),
       'city': new FormControl(''),
      'pincode': new FormControl(''),
      'deptName': new FormControl(''),
      'state':new FormControl('')
    });
   
  }

 
  saveEmp(emp:EmployeeDto) {//same identical property for the formcontrolname
    
    this.empService.saveEmp(emp).subscribe((data) => {
        this.response=data;
        alert("Employee saved !");

    },
      err => {
        alert("Employee not saved !");
      },
      () => { console.log('Method Executed') }
    );
  }


}

