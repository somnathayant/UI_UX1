import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  role: string;

  userRole:boolean=false;
  userAdmin:boolean=false;
  userAccount:boolean=false;
  userInventory:boolean=false;
  constructor() { }

  ngOnInit() {
    this.role=sessionStorage.getItem("role");
alert(this.role);

    if(this.role==="Admin"){
      this.userAdmin=true;


      this.userAccount=true;
      this.userInventory=true;
    }
    if(this.role==="Account"){
     
      this.userAccount=true;

      
      this.userAdmin=false;
      this.userInventory=false;
    } if(this.role==="Inventory"){
     
      this.userInventory=true;
      this.userAccount=false;
      this.userAdmin=false;

    }




    
  }

}
