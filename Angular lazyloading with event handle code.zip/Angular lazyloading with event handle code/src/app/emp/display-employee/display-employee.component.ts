import { Component, OnInit,Output ,EventEmitter,Input } from '@angular/core';

@Component({
  selector: 'app-display-employee',
  templateUrl: './display-employee.component.html',
  styleUrls: ['./display-employee.component.css']
})
export class DisplayEmployeeComponent implements OnInit {

  @Input() parentData: number;
  @Output() valueChange = new EventEmitter();

  counter:number;
  constructor() { 
    console.log(`new - data is ${this.parentData}`);
  }

  ngOnChanges() {
    console.log(`ngOnChanges - data is ${this.parentData}`);
  }

  ngOnInit() {
    this.counter=0;
    console.log(`ngOnInit - data is ${this.parentData}`);
  }

  ngDoCheck() {
    console.log("ngDoCheck");
   
  }

  ngAfterContentInit() {
    console.log("ngAfterContentInit");
  }

  ngAfterContentChecked() {
    console.log("ngAfterContentChecked");
  }

  ngAfterViewInit() {
    console.log("ngAfterViewInit");
  }

  ngAfterViewChecked() {
    console.log("ngAfterViewChecked");
  }

  ngOnDestroy() {
    console.log("ngOnDestroy");
  }

  valueChangeFunction() { // You can give any function name

      this.counter = this.counter + 1;

      this.valueChange.emit(this.counter);

  }


}
