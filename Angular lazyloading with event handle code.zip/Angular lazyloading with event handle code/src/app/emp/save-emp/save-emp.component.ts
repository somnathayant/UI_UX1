import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-save-emp',
  templateUrl: './save-emp.component.html',
  styleUrls: ['./save-emp.component.css']
})
export class SaveEmpComponent implements OnInit {

  data:number;
  constructor() { }

  ngOnInit() {
    this.data=0;
  }
  changeFromParent(){
    this.data += 1;
  }

  
  displayCounter(count:any) {

    alert("in parent+"+count);

}
}
