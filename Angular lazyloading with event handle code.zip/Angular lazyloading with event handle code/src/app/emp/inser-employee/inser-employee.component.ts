import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-inser-employee',
  templateUrl: './inser-employee.component.html',
  styleUrls: ['./inser-employee.component.css']
})
export class InserEmployeeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
