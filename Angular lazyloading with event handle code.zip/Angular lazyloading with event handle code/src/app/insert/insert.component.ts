import { Component, OnInit } from '@angular/core';
import { FormControl, Validators, FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import{StudentService} from '../studentService';
import { StudentDto } from './../StudentDto';

@Component({
  selector: 'app-insert',
  templateUrl: './insert.component.html',
  styleUrls: ['./insert.component.css']
})
export class InsertComponent implements OnInit {

  studentForm: FormGroup;
  
  constructor(private fb: FormBuilder, private studentService : StudentService, private route : Router) { }

  ngOnInit() {
    this.studentForm = this.fb.group({      // initializes all formcontrolnames and give the control to empForm hence it carries all values as a single object.
      'firstName' : new FormControl('',[Validators.required,Validators.minLength(4),Validators.maxLength(10)]),
      'lastName' : new FormControl('',Validators.required),
      'year' : new FormControl('',Validators.required),
      'city' : new FormControl('',[Validators.required,Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$")]),
    });
  }

  get studentFormValues() { return this.studentForm.controls; }//this is for getting values and used in validation


  
  registerStudent(studentDto:StudentDto){   //emp is the model class object
    
    

    this.studentService.saveStudent(studentDto).subscribe((data) => {
      
        //alert("Student saved !");
        //this.route.navigate(['/display']) ;
    },
      err => {
        alert("Student not saved !");
      },
      () => { console.log('Method Executed') }
    );
          
        }



}
