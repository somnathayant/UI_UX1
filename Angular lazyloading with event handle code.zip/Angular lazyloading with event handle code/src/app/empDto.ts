export class EmpDto{

    id:string;
    name:string;
    role:string;

}