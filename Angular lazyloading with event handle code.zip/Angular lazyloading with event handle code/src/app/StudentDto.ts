export class StudentDto{
     id:number;
	 firstName:string;
	 lastName:string;
	 year:string;
	 add_id:number;
	 city:string;
}