import { Component, OnInit } from '@angular/core';
import { Validators, FormControl, FormGroup, FormBuilder } from '@angular/forms';
import {Router} from "@angular/router";
import { EmpDto } from './../empDto';
import {StudentService} from './../studentService';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {


  empLoginForm: FormGroup;

  constructor(private fb: FormBuilder,  private route:Router,private studentService:StudentService) { }

  ngOnInit() {
    this.empLoginForm = this.fb.group({      // initializes all formcontrolnames and give the control to empForm hence it carries all values as a single object.
      'id': new FormControl(''),
      'name': new FormControl('')
  })


  }

  loginEmp(emp:EmpDto) {//same identical property for the formcontrolname
      
    
     this.studentService.getEmpById(emp.id).subscribe((data) => {//here the data is sent to service class method from componenet
      
         alert(data.role);
         if(JSON.stringify(data)!=null){//That means user is registered
           sessionStorage.setItem("role",data.role);
          this.route.navigate(['/dashBoard']);
       }
       else{
         alert("You are not authorized please register first");
       }
   },
     err => {
     },
     () => { console.log('Method Executed') }
   );
   
    }
}
