import { LoginComponent } from './login/login.component';

import { InsertComponent } from './insert/insert.component';
import { DisplayComponent } from './display/display.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import{AuthDashService} from './authDashboard.service';
const routes: Routes = [
  { path: 'dashBoard', component:DashboardComponent},
  { path: 'login', component:LoginComponent},
  { path: '',   redirectTo: '/login', pathMatch:'full'},
  {path:'insert', component:InsertComponent,canActivate : [AuthDashService]},
  { path: 'display', component:DisplayComponent},
  {path: 'employee', loadChildren: () => import(`./emp/emp.module`).then(emp => emp.EmpModule) }
  
  ];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
