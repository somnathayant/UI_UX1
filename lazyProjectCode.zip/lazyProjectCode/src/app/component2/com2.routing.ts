import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { Com2 } from "./com2.component";
 
const routes: Routes = [
    { path:"", component: Com2 }
];
 
@NgModule({
    exports: [RouterModule],
    imports:[RouterModule.forChild(routes)]
})
export class Com2Routing{
    
} 


