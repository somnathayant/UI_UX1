import { NgModule } from "@angular/core";
import { Com2Routing } from "./com2.routing";
import { Com2 } from "./com2.component";
 
@NgModule({
    declarations:[Com2],
    imports:[Com2Routing],
    providers: []
    
})
export class Com2Module{
 
}