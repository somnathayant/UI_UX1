import { NgModule } from '@angular/core';
import { Routes, RouterModule,CanActivate } from '@angular/router';
import{HomeComponent} from './home.component';
import { WelcomeComponentComponent } from './welcome-component/welcome-component.component';
import { AuthGurdService } from './auth-gurd.service';
import { RejetComponentComponent } from './rejet-component/rejet-component.component';
const routes: Routes = [
    {
      path:'',component:HomeComponent
    },
    {
      path:'reject',component:RejetComponentComponent
    },
    {
      path:'welcome',component:WelcomeComponentComponent,canActivate: [AuthGurdService]
    },

    {
      path:"com1",
      loadChildren:'./component1/com1.module#Com1Module'

    },
    {
      path:"com2",
      loadChildren:'./component2/com2.module#Com2Module'
    },
    {
      path:"com3",
      loadChildren:'./component3/com3.module#Com3Module'
    },
];
 
 
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
  providers:[]
})
export class AppRoutingModule { }