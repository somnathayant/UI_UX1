import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './com3.html'
  
})
export class Com3 {
  title = 'lazyProject1';
}