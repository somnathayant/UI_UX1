import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule }      from '@angular/forms';

import { AppComponent } from './app.component';
import{AppRoutingModule} from './app.routing';
import{HomeComponent} from './home.component';
import { WelcomeComponentComponent } from './welcome-component/welcome-component.component';
import { RejetComponentComponent } from './rejet-component/rejet-component.component';
@NgModule({
  declarations: [
    AppComponent,HomeComponent, WelcomeComponentComponent, RejetComponentComponent
  ],
  imports: [
    BrowserModule,AppRoutingModule,FormsModule,ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
