import { Injectable } from '@angular/core';
import { CanActivate,Router} from '@angular/router';
import { LoginDto } from './login.model';

@Injectable({
  providedIn: 'root'
})
export class AuthGurdService implements CanActivate {

  constructor(private route:Router ) { }

  canActivate():boolean{
      let user=localStorage.getItem('name');
      alert(user);
      if(user=="somnath"){
        
        return true;
      }else{
        alert('security-else');
        //this.route.navigate(['/reject']);
        return false;
      }
   }


}
